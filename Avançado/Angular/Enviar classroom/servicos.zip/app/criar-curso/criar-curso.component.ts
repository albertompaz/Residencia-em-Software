import { Component, OnInit } from '@angular/core';
import { CursosService } from '../cursos/cursos.service';

@Component({
  selector: 'app-criar-curso',
  templateUrl: './criar-curso.component.html',
  styleUrls: ['./criar-curso.component.css'] ,
  providers: [CursosService]
})

export class CriarCursoComponent implements OnInit {

  cursos: string[] = [];

  /* injeção de dependencia de CursosService para pegar a informação de curso */
  constructor(private cursosService: CursosService) { }

  // dentro do ngOnInit para pegar a lista dos curso com a inicialização
  ngOnInit() {
      this.cursos = this.cursosService.getCursos();
  }

  // método para chamar o cursosService e adicionar os cursos
  onAddCurso(curso: string) {
    this.cursosService.addCurso(curso);

  }

}
