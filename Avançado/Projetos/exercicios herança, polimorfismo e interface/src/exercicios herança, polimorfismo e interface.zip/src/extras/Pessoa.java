package extras;

public abstract class Pessoa {
	
	public void pessoa() {
		System.out.println("Sou uma pessoa e: ");
	}
	
}
