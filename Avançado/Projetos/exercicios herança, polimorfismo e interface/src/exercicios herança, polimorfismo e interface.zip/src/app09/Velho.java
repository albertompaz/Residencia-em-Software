package app09;

public class Velho extends Imovel{

	private float desconto;

	public float getDesconto() {
		return desconto;
	}

	public void setDesconto(float desconto) {
		this.desconto = desconto;
	}
	
}
