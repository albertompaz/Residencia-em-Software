import { NgElseDirective } from './ng-else.directive';

describe('NgElseDirective', () => {
  it('should create an instance', () => {
    const directive = new NgElseDirective();
    expect(directive).toBeTruthy();
  });
});
