export interface Pessoa {
    id: number;
    cpf: string;
    senha: string;
    tipo: string;
    nome: string;
    email: string;
    telefone: string;
    celular: string;
}