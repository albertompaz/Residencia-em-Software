import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-nao-encontrada',
  templateUrl: './info-nao-encontrada.component.html',
  styleUrls: ['./info-nao-encontrada.component.css']
})
export class InfoNaoEncontradaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
