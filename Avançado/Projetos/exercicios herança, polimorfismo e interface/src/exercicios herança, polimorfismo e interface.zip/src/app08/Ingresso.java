package app08;

public class Ingresso {

	protected float valor;

	
	public float imprimeValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	
}
