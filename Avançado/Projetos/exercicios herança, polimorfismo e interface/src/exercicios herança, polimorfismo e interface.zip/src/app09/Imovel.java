package app09;

public class Imovel {
	
	public String endereco;
	public float preco;
	
	// criando get e set dos atributos
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public float getPreco() {
		return preco;
	}
	public void setPreco(float preco) {
		this.preco = preco;
	}
	
}
