export class Usuario {
    cpf: string;
    senha: string;
}