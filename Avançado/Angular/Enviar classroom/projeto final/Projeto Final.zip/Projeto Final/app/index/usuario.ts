export class Usuario {
    id: number;
    nome: string;
    senha: string;
    pontos: Array<string>;
    
}