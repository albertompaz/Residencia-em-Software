package app09;

public class Novo extends Imovel {
	
	private float adicional;

	public float getAdicional() {
		return adicional;
	}

	public void setAdicional(float adicional) {
		this.adicional = adicional;
	}
	
	
	
}
