package app08;

public class CamaroteInferior extends Vip {
	
	private String localizacaoDoIngresso;

	// get e set para o atributo
	public String getLocalizacaoDoIngresso() {
		return localizacaoDoIngresso;
	}

	public void setLocalizacaoDoIngresso(String localizacaoDoIngresso) {
		this.localizacaoDoIngresso = localizacaoDoIngresso;
	}
	
	
	
}
