import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { CursosService } from '../cursos/cursos.service';
import { CursosComponent } from './cursos.component';

@NgModule({
  declarations: [
    CursosComponent,
  ],
  imports: [
    CommonModule
  ],
  // exportando para o modulo poder ser importado
  exports: [CursosComponent],
  // providers serve pra dizer que estamos solicitando o serviço do CursosService no nosso componente
  providers: [CursosService]
})
export class CursosModule { }
