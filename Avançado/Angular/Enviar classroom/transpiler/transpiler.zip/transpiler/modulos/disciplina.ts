export interface Disciplina {
    id: number;
    nome: string;
    cargaHoraria: number;
}