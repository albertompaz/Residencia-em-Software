import { FundoAmareloDirective } from './fundo-amarelo.directive';

describe('FundoAmareloDirective', () => {
  it('should create an instance', () => {
    const directive = new FundoAmareloDirective();
    expect(directive).toBeTruthy();
  });
});
