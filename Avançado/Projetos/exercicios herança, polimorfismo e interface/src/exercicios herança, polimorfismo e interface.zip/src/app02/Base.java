package app02;

public class Base {
	
	protected String nome;
	protected float preco;
	
	public Base (String nome, float preco){
		this.nome = nome;
		this.preco = preco;
	}
	
}
