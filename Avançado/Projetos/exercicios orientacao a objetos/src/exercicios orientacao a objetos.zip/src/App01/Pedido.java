/* Programa para gerenciar os produtos de uma loja
 * Programador: Alberto Paz
 * Data: 09/12/2019 */

package App01;

public class Pedido {

	private int itens;
	private int quantidade;
	
	
	// gerando get and set para os atributos
	public int getItens() {
		return itens;
	}
	public void setItens(int itens) {
		this.itens = itens;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	
	
	
}
