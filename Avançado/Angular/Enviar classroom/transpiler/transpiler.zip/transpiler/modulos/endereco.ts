export interface Endereco {
    id: number;
    cep: number;
    bairro: string;
    cidade: string;
    rua: string;
    numero: number;
}