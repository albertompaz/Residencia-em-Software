import { Component, OnInit } from '@angular/core';

// importando as classes em que estamos utilizando suas injeções
// para importar o cursosService deve-se informar o caminho igual faz pra entrar em comando cmd
import { CursosService } from './cursos.service';

@Component({
  selector: 'app-cursos',
  templateUrl: './cursos.component.html',
  styleUrls: ['./cursos.component.css']
})
export class CursosComponent implements OnInit { 
 
  // criando a variavel pra ser preenchida pela injeção mais tarde
  cursos: string[] = [];

  // usando a injeçãode dependencia dentro do nosso construtor
  // o private nos permite colocar a utilização dessa variavel que está instanciando o CursosService
  //para ser utilizado dentro do nosso componente
  // tambem está puxando a informação que foi injetada no cara que a gente injetou, que seria do LogService
  // CursosService.logService.<método>
  constructor(private cursosService: CursosService) {}

  ngOnInit() {
    /* fazendo nossa string receber os valores dentro do servico CursoService */
      this.cursos = this.cursosService.getCursos();
      /* subscribe é para receber um evento de informação */
      CursosService.criouNovoCurso.subscribe(
        // adicionando o curso ao vetor através do push
      curso => this.cursos.push(curso)
    );
  }

}
