import { Injectable } from '@angular/core';

// @injectable significa que esse serviço vai poder ser injetado em outro
@Injectable()
export class CursosService {
    // pegando a lista básica dos 3 cursos iniciais e retornando ela
    getCursos() {
        return ['Angular', 'Java', 'Phonegap'];
    }
}
