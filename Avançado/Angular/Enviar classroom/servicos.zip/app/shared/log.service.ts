import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LogService {

  constructor() { }

  // método apenas para mandar uma mensagem no nosso console
  consoleLog(msg: string) {
    console.log(msg);
  }
}
 