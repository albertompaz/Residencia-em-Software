/* Programa para criar um controle de ingressos
 * Programador: Alberto Paz
 * Data: 12/12/2019 */

package app08;

public class Normal extends Ingresso {

	public void tipoIngresso() {
		System.out.println("Ingresso Normal");
	}
	
}
