package app04;

public interface Comparable {

	public String comparacaoPorNome(String nome, String nome2);
	
}
