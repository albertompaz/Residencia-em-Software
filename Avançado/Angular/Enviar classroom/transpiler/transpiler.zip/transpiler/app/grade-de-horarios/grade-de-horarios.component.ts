import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grade-de-horarios',
  templateUrl: './grade-de-horarios.component.html',
  styleUrls: ['./grade-de-horarios.component.css']
})
export class GradeDeHorariosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
