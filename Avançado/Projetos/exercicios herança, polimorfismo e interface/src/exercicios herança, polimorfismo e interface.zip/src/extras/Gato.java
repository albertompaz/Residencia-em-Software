package extras;

public class Gato extends Animal {

	public void miar() {
		System.out.print("Miau Miau Miau");
	}
	
}
