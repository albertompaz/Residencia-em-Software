/* Programa para "controlar" um carro, suas troca de marcha, consumo, etc
 * Programador: Alberto Paz
 * Data: 09/12/2019 */

package App04;

public class Marca {
	
	private String nome;
	private int nrDeModelos;
	private int anoDeLancamento;
	private int codigoIdentificadr;
	
	// get e set para os atributos
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getNrDeModelos() {
		return nrDeModelos;
	}
	public void setNrDeModelos(int nrDeModelos) {
		this.nrDeModelos = nrDeModelos;
	}
	public int getAnoDeLancamento() {
		return anoDeLancamento;
	}
	public void setAnoDeLancamento(int anoDeLancamento) {
		this.anoDeLancamento = anoDeLancamento;
	}
	public int getCodigoIdentificadr() {
		return codigoIdentificadr;
	}
	public void setCodigoIdentificadr(int codigoIdentificadr) {
		this.codigoIdentificadr = codigoIdentificadr;
	}
	
	
	
}
