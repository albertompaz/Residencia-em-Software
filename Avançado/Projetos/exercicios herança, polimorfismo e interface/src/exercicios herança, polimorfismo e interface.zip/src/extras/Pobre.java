package extras;

public class Pobre extends Pessoa {

	public void situacao() {
		System.out.println("Tenho uma casa financiada");
	}
	
}
