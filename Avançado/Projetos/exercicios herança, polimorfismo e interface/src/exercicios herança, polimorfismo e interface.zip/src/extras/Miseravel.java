package extras;

public class Miseravel extends Pessoa {

	public void situacao() {
		System.out.println("Moro de baixo da ponte pois n�o estudei Java");
	}
	
}
