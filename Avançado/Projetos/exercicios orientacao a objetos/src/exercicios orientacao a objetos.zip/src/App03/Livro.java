/* Programa para controlar o  emprestimo de um livro
 * Programador: Alberto Paz
 * Data: 09/12/2019 */

package App03;

public class Livro {
	
	private String nome;
	private String editora;
	private int registro;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEditora() {
		return editora;
	}
	public void setEditora(String editora) {
		this.editora = editora;
	}
	public int getRegistro() {
		return registro;
	}
	public void setRegistro(int registro) {
		this.registro = registro;
	}
	
	

}
