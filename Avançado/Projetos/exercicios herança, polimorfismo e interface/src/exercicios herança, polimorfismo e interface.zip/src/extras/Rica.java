package extras;

public class Rica extends Pessoa {
	
	public void situacao() {
		System.out.println("Tenho uma mans�o");
	}
	
}
