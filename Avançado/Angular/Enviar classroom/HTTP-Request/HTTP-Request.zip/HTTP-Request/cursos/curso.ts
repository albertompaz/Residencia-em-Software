// arquivo de especificação para criar uma interface dos dados a serem utilizados dentro da nossa aplicação
// para conseguirmos implementar nossos parametros de CRUD, pra saber com qual informação eles estão lidando
// sem esse arquivo não conseguimos criar nossos arrays de informação
export interface Curso {
    id: number;
    nome: string;
  }