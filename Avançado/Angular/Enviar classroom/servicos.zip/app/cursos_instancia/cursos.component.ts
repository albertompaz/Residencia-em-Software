import { Component, OnInit } from '@angular/core';

import { CursosService } from './cursos.service';

@Component({
  selector: 'app-cursosInstancia',
  templateUrl: './cursos.component.html',
  styleUrls: ['./cursos.component.css']
})
export class CursosComponent implements OnInit {

  cursos: string[] = [];

  cursosService: CursosService;

  // fazedo uma injeção de CursosService
  constructor() {
      this.cursosService = new CursosService();
  }

  // pegando a lista de cursos pré estabelecida na inicialização do programa
  ngOnInit() {
      this.cursos = this.cursosService.getCursos();
  }

}
