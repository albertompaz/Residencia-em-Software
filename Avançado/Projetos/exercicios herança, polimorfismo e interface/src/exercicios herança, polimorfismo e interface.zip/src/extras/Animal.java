package extras;

public abstract class Animal {
	
	public void caminhar() {
		System.out.print("Estou caminhando");
	}
	
}
