import { HighlightMouseDirective } from './highlight-mouse.directive';

describe('HighlightMouseDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlightMouseDirective();
    expect(directive).toBeTruthy();
  });
});
