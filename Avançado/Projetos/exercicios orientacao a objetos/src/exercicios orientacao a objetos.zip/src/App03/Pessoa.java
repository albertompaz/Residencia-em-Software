/* Programa para controlar o  emprestimo de um livro
 * Programador: Alberto Paz
 * Data: 09/12/2019 */

package App03;

public class Pessoa {
	
	private String nome;
	private int idade;
	private String cpf;
	
	
	// Get e Set para os atributos
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	
	
}
