/* Programa para criar um controle de ingressos
 * Programador: Alberto Paz
 * Data: 12/12/2019 */

package app08;

public class CamaroteSuperior extends Vip {

	public float valorAdicioal(float adicional) {
		this.valor = valor+adicional;
		return valor;
	}
	
}
