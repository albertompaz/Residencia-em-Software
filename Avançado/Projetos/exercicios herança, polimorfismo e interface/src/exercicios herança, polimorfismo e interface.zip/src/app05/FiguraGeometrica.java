/* Programa para calculo de area e perimetro de figuras geometricas
 * Programador: Alberto Paz
 * Data: 11/12/2019 */

package app05;

public interface FiguraGeometrica {
 
	public float getPerimetro();
	public float getArea();
	
}
