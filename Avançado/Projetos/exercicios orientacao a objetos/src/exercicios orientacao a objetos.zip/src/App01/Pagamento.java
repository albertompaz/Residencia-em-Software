/* Programa para gerenciar os produtos de uma loja
 * Programador: Alberto Paz
 * Data: 09/12/2019 */

package App01;

public class Pagamento {

	private String tipoPagamento;
	
	// criando get and set
	public String getTipoPagamento() {
		return tipoPagamento;
	}
	public void setTipoPagamento(String tipoPagamento) {
		this.tipoPagamento = tipoPagamento;
	}	
	
}
