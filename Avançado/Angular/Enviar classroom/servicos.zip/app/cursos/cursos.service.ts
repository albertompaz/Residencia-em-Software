import { EventEmitter, Injectable } from '@angular/core';

import { LogService } from './../shared/log.service';
 
// @injectable significa que esse serviço vai poder ser injetado em outro
@Injectable()
export class CursosService {

    // criando uma emissão de evento
    static criouNovoCurso = new EventEmitter<string>();

    emitirCursoCriado = new EventEmitter<string>();

    private cursos: string[] = ['Angular', 'Java', 'Phonegap'];

    constructor(private logService: LogService){
        console.log('CursosService');
    }

    // get para pegar a lista dos cursos
    getCursos() {
        this.logService.consoleLog('Obtendo lista de cursos');
        return this.cursos;
    }


    addCurso(curso: string) {
        this.logService.consoleLog('Criando um novo curso ' + curso);
        // adicionando o curso na ultima posição na lista de cursos
        this.cursos.push(curso);
        // emitindo os eventos para poderem ser escutados mais tarde em outro componente
        this.emitirCursoCriado.emit(curso);
        CursosService.criouNovoCurso.emit(curso);
    }
}
